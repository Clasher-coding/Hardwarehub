import React, { useEffect, useState } from "react";
import Heading from "../Products/Heading";
import Product from "../Products/Product";

const SpecialOffers = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5001/products")
      .then((res) => res.json())
      .then((data) => {
      
        const specialOffers = data.filter((product) => product.isSpecialOffer);
        setProducts(specialOffers);
      })
      .catch((err) => console.error("Error fetching products:", err));
  }, []);

  return (
    <div className="w-full pb-20">
      <Heading heading="Special Offers" />
      <div className="w-full grid grid-cols-1 md:grid-cols-2 lgl:grid-cols-3 xl:grid-cols-4 gap-10">
        {products.map((product) => (
          <Product
            key={product._id}
            _id={product._id}
            img={`http://localhost:5001${product.image}`} 
            productName={product.name}
            price={product.discountPrice || product.price} // Use discount price if available
            oldPrice={product.price} // Original price
            discount={product.discount} // Discount percentage
            stock={product.stock} // Stock availability
            color="Black"
            badge={true}
            des={product.description}
          />
        ))}
      </div>
    </div>
  );
};

export default SpecialOffers;
